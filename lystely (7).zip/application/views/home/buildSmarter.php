<section class="bg-white build-smarter py-5">
    <div class="container">
        <h2 class="Poppins-Medium text-center font-34 text-Elephant">Build smarter shopper experiences across the <br/> customer journey</h2>
        <p class="text-center">Leverage our unsurpassed network spanning every part of your customer’s journey. Across retail, social, online, and in-store, we connect 24,500+ of the world’s leading brands and retailers with their customers. In more ways. Better ways. More impactful ways.</p>
        <img src="https://s3-eu-west-1.amazonaws.com/lystley.com/home/Buld smart shopper.svg" alt="Build smarter shopper experiences across the customer journey" class="img-fluid py-4" />
    </div>
</section>
