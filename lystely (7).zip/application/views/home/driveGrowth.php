<section class="bg-jungle-green drive-growth py-md-5 py-3">
    <div class="container py-3">
        <h2 class="text-white Poppins-Medium">Drive growth and improve performance across <br/> business verticals</h2>
        <p class="text-white Poppins-Light">Synup’s Digital Profile Management Solution drives brand awareness, customer <br/> acquisition, and loyalty</p>
    </div>
    <div class="container-fluid bg-white-smoke py-5">
        <div class="row">
            <div class="col">
                <img src="assets/images/home/Group 17860.png" alt="Group 17860" class="img-fluid" />
            </div>
            <div class="col">
                <img src="assets/images/home/Group 17855.png" alt="Group 17855" class="img-fluid" />
            </div>
            <div class="col">
                <img src="assets/images/home/Group 17856.png" alt="Group 17856" class="img-fluid" />
            </div>
            <div class="col">
                <img src="assets/images/home/Group 17857.png" alt="Group 17805" class="img-fluid" />
            </div>
            <div class="col">
                <img src="assets/images/home/Group 17858.png" alt="Group 17858" class="img-fluid" />
            </div>
            <div class="col">
                <img src="assets/images/home/Group 17859.png" alt="Group 17859" class="img-fluid" />
            </div>
        </div>
    </div>
</section>