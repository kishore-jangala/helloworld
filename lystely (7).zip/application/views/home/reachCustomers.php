<section class="reach-customers py-5">
    <div class="container">
        <h2 class="Poppins-Medium text-center text-Elephant">Reach customers <br /> everywhere</h2>
        <img src="assets/images/home/reach-customers.svg" alt="Reach customers everywhere" class="img-fluid py-4" />
        <div class="d-flex justify-content-center">
            <button class="lets-talk">LET’S TALK <img src="assets/images/side arrow.svg" alt="side arrow" class="ml-2"/></button>
        </div>
    </div>
</section>