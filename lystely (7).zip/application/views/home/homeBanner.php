<section class="lys-banner hide-banner-for-small">
	<div class="container h-100">
		<div class="row h-100 align-items-center">
			<div class="col-md-4">
				<h1 class="text-Elephant Poppins-Medium">Be <span class="Poppins-SemiBold">Choosen</span> <br /> Always</h1>
				<h2 class="text-Elephant my-4 Poppins-Regular">Increase brand awareness, customer <br /> acquisition, and loyalty.</h2>
				<button class="lets-talk">LET’S TALK</button>
			</div>
		</div>
	</div>
</section>
<section class="hide-banner-for-lg green-shade-bg lys-banner-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-7 col-lg-7 mb-3 hide-for-lg">
				<img src="https://s3-eu-west-1.amazonaws.com/lystley.com/home/Home_image_Mobile.svg" class="img-fluid" alt="Home_image_Mobile" />
			</div>
			<div class="col-md-5 col-lg-5 align-self-center">
                <div class="lystely-banner-content">
				<h1 class="text-Elephant font-24 Poppins-Medium">Be <span class="Poppins-SemiBold">Choosen</span> <br /> Always</h1>
				<h2 class="text-Elephant font-14 my-4 Poppins-Regular">Increase brand awareness, customer <br /> acquisition, and loyalty.</h2>
				<button class="lets-talk">LET’S TALK</button>
				</div>
			</div>
		</div>
</section>