<section class="conatct-banner">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <div class="p-5">
                <h1 class="Poppins-Bold text-white mt-5">We’d love to hear <br /> from you</h1>
                <h2 class="Poppins-Regular font-20 text-white">Get in touch.</h2>
            </div>
        </div>
    </div>
</section>