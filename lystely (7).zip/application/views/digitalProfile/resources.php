<section class="resources">
    <div class="container py-5">
        <h2 class="Poppins-Bold font-32 text-Elephant my-4">Resources</h2>
        <div class="row ">
            <div class="col-md-4">
                <div class="resources-card py-5 px-4">
                    <h3 class="text-jungle-green font-14 Poppins-SemiBold">CASE STUDY</h3>
                    <h4 class="text-Elephant font-24 Poppins-Bold"> Verizon</h4>
                    <p class="text-Elephant font-14 Poppins-Medium  py-5">How Verizon personalizes its brand &experiences for hundreds of locations</p>

                    <a class="pt-4 read-more text-Elephant font-11 Poppins-Bold" href="#">READ MORE</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="resources-card py-5 px-4">
                    <h3 class="text-jungle-green font-14 Poppins-SemiBold">CASE STUDY</h3>
                    <h4 class="text-Elephant font-24 Poppins-Bold"> Verizon</h4>
                    <p class="text-Elephant font-14 Poppins-Medium  py-5">How Verizon personalizes its brand &experiences for hundreds of locations</p>

                    <a class="pt-4 read-more text-Elephant font-11 Poppins-Bold" href="#">READ MORE</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="resources-card py-5 px-4">
                    <h3 class="text-jungle-green font-14 Poppins-SemiBold">CASE STUDY</h3>
                    <h4 class="text-Elephant font-24 Poppins-Bold"> Verizon</h4>
                    <p class="text-Elephant font-14 Poppins-Medium  py-5">How Verizon personalizes its brand &experiences for hundreds of locations</p>

                    <a class="pt-4 read-more text-Elephant font-11 Poppins-Bold" href="#">READ MORE</a>
                </div>
            </div>

        </div>
    </div>
    <p class=" text-center mb-5"><a class="see-all-resourses text-Elephant pb-5 font-12 Poppins-Bold" href="#">SEE ALL RESOURCES</a></p>
</section>