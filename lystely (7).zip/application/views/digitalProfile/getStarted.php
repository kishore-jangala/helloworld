<section class="get-started bg-jungle-green">
    <div class="container">
        <div class="text-center text-white p-5">
            <h2 class="Poppins-Bold font-32 ">Get Started</h2>
            <p class="Poppins-Regular font-14 my-3">Get in touch to find out which solutions will make the most impact for your business. Our helpful <br/> sales team can answer your questions and talk about everything from set up to ROI.</p>
            <button class="book-call Poppins-Medium">Book a call</button>
        </div>
    </div>
</section>